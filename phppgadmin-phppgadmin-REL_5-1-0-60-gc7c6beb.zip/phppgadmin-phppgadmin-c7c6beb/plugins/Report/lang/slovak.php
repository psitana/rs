<?php
	/**
	 *	Slovenska lokalizacia phpPgAdmin-u.
	 */

	// Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';
	$plugin_lang['strnoreportsdb'] = 'Nebola vytvorené report databáza. Prečítaj si INSTALL súbor s pokynmi.';

	// Reports
	$plugin_lang['strreport'] = 'Report';
	$plugin_lang['strreports'] = 'Reporty';
	$plugin_lang['strshowallreports'] = 'Zobraziť Všetky Reporty';
	$plugin_lang['strnoreports'] = 'Nenájdené žiadne reporty.';
	$plugin_lang['strcreatereport'] = 'Vytvoriť Report';
	$plugin_lang['strreportdropped'] = 'Report zmazaný.';
	$plugin_lang['strreportdroppedbad'] = 'Report nebol zmazaný.';
	$plugin_lang['strconfdropreport'] = 'Naozaj chceš zmazať report "%s"?';
	$plugin_lang['strreportneedsname'] = 'Musíš zadať názov pre tvoj report.';
	$plugin_lang['strreportneedsdef'] = 'Musíš zadať SQL dotaz pre tvoj report.';
	$plugin_lang['strreportcreated'] = 'Report uložený.';
	$plugin_lang['strreportcreatedbad'] = 'Report nebol uložený.';
?>
